---
name: llc-financials-from-bank-statements
description: Use when building LLC financial statements from checking bank statements and credit-card statements, especially for tax packages, K-1 support, CPA packages, or requests to classify bank activity into P&L versus Balance Sheet with member contributions, distributions, related-party transfers, pass-through clearing, credit-card payments, and operating income or expenses.
---

# LLC Financials From Bank Statements

## Overview

Build a minimal, CPA-reviewable workbook from bank activity for a single LLC and tax year. The output must separate true operating income and expenses from balance-sheet activity such as capital contributions, member distributions, related-party clearing, pass-through money, investment distributions, credit-card liability activity, and reversals.

The standard workbook has exactly three visible tabs:

1. `P&L 2025` or `P&L <year>`
2. `Balance Sheet`
3. `Transaction Detail`

Always use the `spreadsheets` skill and `@oai/artifact-tool` for final workbook authoring.

## Required References

Read these before acting:

- `references/accounting-treatment.md` for classification rules.
- `references/workbook-spec.md` for tab structure, formulas, formatting, and output standard.
- `references/review-checklist.md` before final delivery.

Read `references/input-normalization.md` when inputs include PDFs, CSVs, Excel exports, credit-card statements, multiple bank accounts, or unclear running balances.

## Workflow

### 1. Plan

Identify the entity, tax year, and source accounts. Inputs may include:

- Checking account bank statements or activity exports.
- Credit-card statements or activity exports.
- Existing draft P&L or balance sheet files.
- CPA comments, management explanations, invoices, or ownership details.

State the working assumptions briefly if the user did not provide them. Do not stop for clarification unless classification would materially change tax reporting and cannot be inferred.

### 2. Normalize

Create one transaction list for the tax year. Preserve dates, descriptions, amounts, account names, source categories, transaction types, and running balances when available.

For credit cards:

- Include every charge, refund, fee, interest item, and payment in the credit-card transaction detail.
- Do not treat checking-account payments to a credit card as P&L expenses.
- Use credit-card charges to classify expenses.
- Use payments to reduce the credit-card liability.
- Show ending unpaid credit-card balance as a liability.

### 3. Classify

Assign every row:

- `Final Category`
- `Statement` as `P&L` or `Balance Sheet`
- `P&L Line`
- `P&L Amount`
- `BS Line`
- `BS Counterpart Amount`
- `Review Status` when support is missing or judgment is required

Default rule: cash movement is not automatically P&L. Classify by the economic nature of the transaction.

Use CPA-presentable account names in `Final Category`, `P&L Line`, and `BS Line`. Names must be clear, professional, and specific. Do not use slash-combined names that read as uncertain, speculative, or like multiple possible treatments, such as `Due from related parties / advances receivable / transfer clearing`, `Investment / project assets`, `Loan / advance receivable`, or `Transfers / related-party payments`.

When a transaction is uncertain, choose the most defensible accounting treatment and put the uncertainty in `Review Status`, such as `Support Needed`, `CPA Review`, or `Credit Card Statements Needed`. Do not put uncertainty into the account name. Prefer separate, direct names such as `Due from related parties`, `Related-party advances receivable`, `Loan receivable`, `Transfer clearing`, `Investment in partnerships`, `Project deposits`, `Member distributions`, and `Capital contributions`.

### 4. Build

Create a new workbook, not a modified source file. Use formulas in the P&L and Balance Sheet to pull from `Transaction Detail`.

Use the same minimal style used in Coxshire and VCP Equity Management:

- No colors.
- No notes on P&L or Balance Sheet.
- No gridlines on P&L or Balance Sheet.
- No borders on P&L or Balance Sheet unless the user explicitly asks.
- Clear section headers with bold only.
- Currency numbers as typed numeric values, not text.

### 5. Review

Before delivery:

- Reconcile transaction total to ending cash movement.
- Reconcile checking and credit-card payments without double counting.
- Confirm all balance-sheet exclusions from P&L are visible in `Transaction Detail`.
- Confirm `Balance Check` is zero or explain the exact unresolved delta.
- Render all three tabs and visually inspect readability.
- Scan for formula errors.

## Workbook Formulas

Use bounded ranges sized to the actual transaction table. Avoid full-column formulas.

Typical P&L formula:

```excel
=SUMIFS('Transaction Detail'!$I$2:$I$101,'Transaction Detail'!$H$2:$H$101,A7)
```

Typical expense formula when expenses are stored as negative transaction amounts:

```excel
=-SUMIFS('Transaction Detail'!$I$2:$I$101,'Transaction Detail'!$H$2:$H$101,A16)
```

Typical Balance Sheet formula:

```excel
=SUMIFS('Transaction Detail'!$K$2:$K$101,'Transaction Detail'!$J$2:$J$101,A18)
```

Use the sheet name in single quotes for every cross-sheet formula.

## Script Template

When useful, adapt `scripts/build_workbook_from_normalized_json.mjs`. It expects normalized transaction JSON and creates the three-tab workbook with formula-linked P&L and Balance Sheet.

Do not run the script blindly on raw bank files. First normalize and classify the activity according to the references.

## Final Response

Return only:

- A short summary of key accounting treatment applied.
- One Markdown link to the final `.xlsx`.

Mention unresolved support gaps only if they affect the numbers or CPA review.
