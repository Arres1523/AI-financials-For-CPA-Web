# Accounting Treatment Reference

## Core Principle

Classify each transaction by economic substance, not by cash direction. Inflows are not automatically income. Outflows are not automatically expenses.

The P&L should include operating income and operating expenses. The Balance Sheet should include capital activity, member distributions, loans, payables, receivables, clearing items, pass-through cash, credit-card liabilities, and investment basis activity.

Use clear, professional, CPA-presentable account names. Do not combine possible treatments with slashes in `Final Category`, `P&L Line`, or `BS Line`. Pick the most defensible treatment and put unresolved support in `Review Status`.

## P&L Income

Classify as P&L income when the LLC earned revenue from services, fees, reimbursements that are revenue in substance, or normal operations.

Common P&L income lines:

- Management fee income
- Asset management fee income
- Acquisition fee income
- Guarantor fee income
- Reimbursement income, when the LLC is being reimbursed for an expense it incurred and the books treat the gross expense and reimbursement separately
- Merchant or processing income
- Other operating income

If a reimbursement offsets a specific expense and management wants net presentation, use the same P&L line as a contra-expense or a separate reimbursement income line consistently.

## P&L Expenses

Classify as P&L expense when the LLC paid for goods or services used in its business.

Common P&L expense lines:

- Bank fees, net of fee reversals
- Filing fees
- Professional fees
- Legal and accounting
- Software and subscriptions
- Administrative expenses
- Contractor, staffing, or vendor expense
- Business development, conference, meals, and travel
- Payroll, wages, or contractor labor if support shows the LLC paid for its own operating personnel
- Interest, card fees, or other financing costs when supported

Do not put an outflow in the P&L only because cash left the bank. Require business purpose or support.

## Member Contributions

Cash received from a member, member-owned entity, or owner-controlled source for funding the LLC is not income.

Treatment:

- `Statement`: Balance Sheet
- `BS Line`: `Capital contributions`, or `Due to related parties` if management says it is an advance or loan payable
- P&L amount: 0

Decision:

- If management calls it a contribution or funding with no repayment obligation: equity.
- If management calls it an advance, loan, or due back: liability.
- If unclear and material: mark `Review Status` as `Support Needed`.

## Member Distributions and Draws

Cash paid to a legal member, member-owned entity, or beneficial owner as distribution, draw, or cash-flow split is not a P&L expense.

Treatment:

- `Statement`: Balance Sheet
- `BS Line`: Member distributions
- P&L amount: 0

Legal member matters. If the operating agreement lists entity members, distributions to those entities are member distributions. Payments to non-member related parties require separate analysis.

## Related-Party Payments

Payments to related parties do not automatically become expenses. Use support and legal relationship:

- Payment to a legal member or member entity with distribution language: member distribution, equity.
- Payment to a non-member related party for services with invoice or business purpose: P&L expense.
- Payment to a related entity with no service and no repayment obligation, effectively moving owner money out: member distribution, equity.
- Payment to a related entity that should be repaid: due from related party, asset.
- Payment made by mistake and later reversed: clearing item, net zero, no P&L.

If support is missing, default to Balance Sheet clearing for material related-party transfers and mark `Review Status` as `Support Needed`.

## Pass-Through and Clearing Transactions

Pass-through money that enters and exits the LLC without belonging to the LLC is not income or expense.

Examples:

- Investor funds routed through the wrong LLC account.
- Funds received from one entity and immediately paid to another entity for the same purpose.
- Wrong-account deposits.
- Reversed ACH or wire payments.

Treatment:

- Incoming pass-through cash: use `Due to related parties` when the cash must be remitted, or `Transfer clearing` for temporary wrong-account routing.
- Outgoing pass-through cash: reduce the clearing liability, use `Due from related parties` or `Related-party advances receivable` if cash was advanced out before reimbursement, or use `Transfer clearing` for temporary timing and reversal items.
- P&L amount: 0.

If the same dollar amount comes in and goes out for the same stated purpose, the net P&L effect should usually be zero.

## Investment Distributions Received

Cash distributions received from another LLC, partnership, or investee are not operating income by default.

Treatment depends on support:

- If K-1, capital account, or basis schedule is available: record taxable/book income or loss from that support, and treat cash distributions as reductions of investment basis or equity investment receivable.
- If only bank activity is available: exclude cash distribution from P&L and classify as Balance Sheet activity, commonly `Investment distribution received` or `Investment in partnerships`.
- Do not infer taxable income from cash distributions alone.

## Investments and Capital Calls

Cash sent to another entity as an investment, capital call, or project contribution is not a P&L expense.

Treatment:

- `Statement`: Balance Sheet
- `BS Line`: `Investment in partnerships`, `Project deposits`, or `Capital contributions to investments`
- P&L amount: 0

If management says the LLC merely passed investor funds through and does not own the investment, use pass-through clearing instead.

## Credit Cards

Credit-card accounting must avoid double counting.

When both checking and card statements are available:

- Card charges are the source of P&L expenses.
- Card payments from checking are Balance Sheet activity that reduces credit-card payable.
- Unpaid ending card balance is a Balance Sheet liability.
- Refunds reduce the related expense category or appear as contra-expense.
- Interest and card fees are P&L expenses.

When only checking statements are available and payments to a card appear:

- Do not classify total card payments as one P&L expense.
- Classify as `Credit card payable` on the Balance Sheet.
- Mark `Review Status` as `Credit Card Statements Needed`.

## Reversals and Refunds

Reversals should usually net against the original transaction.

Examples:

- Bank fee and fee reversal: net bank fee in P&L.
- ACH sent by mistake and returned: Balance Sheet clearing, net zero.
- Vendor refund for a business expense: reduce the same P&L expense category unless management wants gross reimbursement presentation.

## Beginning Balances

If only current-year bank transactions are provided and no 12/31 prior-year balance is available, do not invent non-cash assets or liabilities.

Use available evidence:

- Cash ending balance from the final statement or running bank balance.
- Credit-card ending balance from the final card statement.
- Beginning equity as needed to balance only when prior-year support or opening cash exists.

If the workbook is cash-activity based and beginning cash is zero, equity will often equal net Balance Sheet activity plus current-year net income.

## Classification Bias

For unclear material items:

1. Avoid putting it in P&L unless there is business-purpose support.
2. Use Balance Sheet clearing or due-to/due-from related party when the cash belongs to another entity or is unresolved.
3. Mark the row for review.
4. Keep the amount visible in Transaction Detail so the CPA can override classification.
