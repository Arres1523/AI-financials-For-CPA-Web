# Input Normalization

## Goal

Convert all source statements into one clean transaction table for the requested entity and year before classification.

## Source Priority

Prefer source detail in this order:

1. Bank or credit-card CSV exports with transaction-level rows.
2. Excel exports from banks, QuickBooks, or prior CPA packages.
3. PDF statements parsed into transaction rows.
4. Existing draft P&L or Balance Sheet only as a cross-check, not as the primary source.

## Required Fields

Normalize each transaction to:

- `date`
- `source_account`
- `description`
- `amount`
- `source_category`
- `type`
- `source_balance`
- `source_file`

If a field is missing, keep it blank rather than inventing it.

## Date Filtering

Include only transactions within the requested tax year:

- Start: January 1
- End: December 31

If a statement period crosses year-end, include only dated transactions within the requested year.

## Multi-Account Handling

When there are multiple checking accounts:

- Normalize each account separately.
- Preserve `source_account`.
- Combine all transactions into `Transaction Detail`.
- Calculate cash as the sum of ending balances, or as beginning cash plus net cash activity if opening balances are known.

When there are checking and credit-card accounts:

- Include checking and credit-card transactions in the same detail tab.
- Add a `Source Account` column.
- Avoid double counting checking payments to the card and card charges.

## Credit-Card Sign Convention

Normalize credit-card data consistently:

- Charges: negative if using cash-flow sign convention.
- Refunds or credits: positive.
- Payments from checking to card: positive on the card statement and negative on checking, but net to zero across cash plus liability.

If the bank export uses the opposite sign convention, convert it before classification and keep numeric values typed.

## Running Balances

Use running balance only when it is reliable and chronological. Some bank exports sort transactions differently and source balance may not represent chronological ending cash.

If source balance order is unreliable:

- Use official statement ending balance if available.
- Otherwise calculate ending cash as beginning cash plus net cash activity.
- If beginning cash is unavailable, use the final reliable running balance only if the source order is chronological.

## Duplicate and Reversal Checks

Check for:

- Same-day equal and opposite amounts.
- Credit returns with matching original ACH/wire.
- Bank fee reversals.
- Credit-card payments appearing in both checking and card statements.
- Same invoice paid by one LLC and reimbursed by another LLC.

Classify true reversals and pass-through items as Balance Sheet or net-zero activity rather than P&L.

## Existing QuickBooks Categories

QuickBooks categories are useful clues, not final accounting treatment.

Override QuickBooks categories when:

- A credit-card payment is categorized as an expense.
- A member contribution is categorized as income.
- A member distribution is categorized as expense.
- A related-party transfer lacks invoice or service support.
- A pass-through amount is categorized as revenue or vendor expense.

Keep the original category in `Source Category` and the corrected category in `Final Category`.
