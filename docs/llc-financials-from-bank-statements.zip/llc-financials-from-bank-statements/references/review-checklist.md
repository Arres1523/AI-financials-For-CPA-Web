# Review Checklist

## Source Completeness

- Confirm the entity name and tax year.
- Confirm all checking accounts for the entity were included.
- Confirm all credit-card accounts in the entity name were included, if applicable.
- Confirm date filtering includes January 1 through December 31 only.
- Confirm source files are not mixed across entities.

## Transaction Classification

Review every material transaction:

- Inflows from members are Balance Sheet, not P&L income.
- Outflows to members are Balance Sheet, not P&L expense.
- Related-party transfers have support or are Balance Sheet clearing.
- Pass-through funds net to zero P&L.
- Wrong-account deposits are clearing items.
- Reversals net against original transactions.
- Investment distributions are not P&L income unless K-1 or income support says so.
- Investment capital calls are not P&L expenses.
- Credit-card payments are not P&L expenses when card charges are available.
- Uncertain treatment is reflected in `Review Status`, not in account names.
- `Final Category`, `P&L Line`, and `BS Line` use one clear CPA-presentable account name each, with no slash-combined uncertainty labels.

## P&L Review

- Total income is only operating income or supported fee income.
- Expenses are only business operating expenses.
- Expense signs display positive on the P&L.
- Fee reversals net correctly.
- Credit-card charges, not card payments, drive expense categories.
- Net income formula references total income and total expenses.

## Balance Sheet Review

- Cash ties to statement ending balances or documented cash roll-forward.
- Credit-card payable ties to the final card statement balance.
- Due from and due to related parties reflect unresolved clearing items only.
- Member contributions and distributions are in equity.
- Current-year net income ties directly to the P&L.
- Total assets equal total liabilities plus equity.
- Balance check is zero or the unresolved delta is clearly identified before final response.

## Formula and Workbook QA

- P&L and Balance Sheet values are formulas from `Transaction Detail`.
- No formula uses full-column references.
- No `#REF!`, `#DIV/0!`, `#VALUE!`, `#NAME?`, or `#N/A` errors.
- Numeric cells are typed numbers, not strings.
- Dates are real dates.
- P&L and Balance Sheet have no gridlines, colors, borders, or notes unless requested.
- Transaction Detail has full classification columns.
- P&L, Balance Sheet, `Final Category`, `P&L Line`, and `BS Line` do not contain ambiguous slash-combined account names.
- All tabs are rendered and visually inspected before export.

## Final Response

State:

- Output workbook link.
- Net income.
- Ending cash and any credit-card payable, if relevant.
- Any unresolved support needed for material transactions.

Do not include internal script paths, preview image paths, or implementation details unless the user asks.
