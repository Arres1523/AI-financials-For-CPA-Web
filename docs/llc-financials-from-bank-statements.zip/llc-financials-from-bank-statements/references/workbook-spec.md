# Workbook Specification

## Required Tabs

Create exactly these visible tabs unless the user asks for additional support tabs:

1. `P&L <year>`
2. `Balance Sheet`
3. `Transaction Detail`

The workbook should be sober, minimal, and CPA-reviewable. Do not add explanatory notes to P&L or Balance Sheet unless the user requests them.

## Account Naming Standard

Account names in `Final Category`, `P&L Line`, and `BS Line` must be clear, professional, and CPA-presentable. Do not use slash-combined names that make the account look ambiguous, speculative, or unresolved, such as `Due from related parties / advances receivable / transfer clearing`, `Investment / project assets`, `Loan / advance receivable`, or `Transfers / related-party payments`.

Use one defensible account name per row and put uncertainty in `Review Status`, not in the account name. Acceptable names include `Due from related parties`, `Related-party advances receivable`, `Loan receivable`, `Transfer clearing`, `Investment in partnerships`, `Project deposits`, `Member distributions`, and `Capital contributions`.

## P&L Format

Use this structure:

```text
Entity Name
Profit and Loss
For the year ended December 31, <year>

Category                         Amount
Income
<income line>
Total Income

Expenses
<expense line>
Total Expenses

Net Income (Loss)
```

Use only lines that have activity or are standard for the entity. For small entities with no operating activity, `Operating income` and `Bank fees` are enough.

Values must be formulas from `Transaction Detail`.

Income formula pattern:

```excel
=SUMIFS('Transaction Detail'!$I$2:$I$101,'Transaction Detail'!$H$2:$H$101,A7)
```

Expense formula pattern when transaction detail stores expenses as negative amounts:

```excel
=-SUMIFS('Transaction Detail'!$I$2:$I$101,'Transaction Detail'!$H$2:$H$101,A16)
```

Net income formula:

```excel
=Total Income - Total Expenses
```

## Balance Sheet Format

Use this structure:

```text
Entity Name
Balance Sheet
As of December 31, <year>

Category                         Amount
Assets
Cash - <bank/account label>
Credit card receivable or due from related parties, if applicable
Investments, if applicable
Total Assets

Liabilities
Credit card payable, if applicable
Due to related parties, if applicable
Transfer clearing, if applicable
Other liabilities identified from support
Total Liabilities

Equity
Beginning members' equity
Capital contributions
Investment distribution received, if applicable and no basis schedule exists
Member distributions
Current year net income (loss)
Total Equity

Total Liabilities and Equity
Balance Check
```

Balance Sheet values must be formulas from `Transaction Detail` except hardcoded beginning balances supported by prior-year statements or provided opening balance schedules.

Common formulas:

```excel
=SUM('Transaction Detail'!$D$2:$D$101)
=SUMIFS('Transaction Detail'!$K$2:$K$101,'Transaction Detail'!$J$2:$J$101,A16)
='P&L 2025'!B25
=Total Assets - Total Liabilities - Total Equity
```

`Balance Check` must be zero before final delivery unless an unresolved source limitation exists.

## Transaction Detail Format

Use this column structure. Keep formulas in P&L and BS amount columns:

| Column | Header | Purpose |
|---|---|---|
| A | Date | Transaction date as a real date |
| B | Source Account | Checking, credit card, account ending, or statement name |
| C | Description | Full bank/card description |
| D | Amount | Signed transaction amount |
| E | Source Category | Original category, if any |
| F | Final Category | Accounting category assigned by the agent; must be CPA-presentable and not slash-combined |
| G | Statement | `P&L` or `Balance Sheet` |
| H | P&L Line | P&L line item, blank if not P&L; must be CPA-presentable and not slash-combined |
| I | P&L Amount | Formula, amount only when Statement is P&L |
| J | BS Line | Balance Sheet line item, blank if not BS; must be CPA-presentable and not slash-combined |
| K | BS Counterpart Amount | Formula, amount only when Statement is Balance Sheet |
| L | Type | ACH, wire, debit card, credit card, fee, refund, etc. |
| M | Source Balance | Running balance when available |
| N | Review Status | Blank, `Support Needed`, `CPA Review`, `Credit Card Statements Needed`, etc. |

If the source workbook already uses a smaller structure, preserve needed source fields but still add the classification columns above.

## Sign Convention

Use signed source amounts:

- Cash/card inflows as positive.
- Cash/card outflows as negative.
- P&L expenses shown as positive on the P&L by multiplying negative transaction amounts by `-1`.
- Balance Sheet equity distributions shown as negative in equity.

For credit cards:

- Charges are usually negative or positive depending on export. Normalize to a consistent sign convention before formulas.
- Payments reduce the liability and should not hit P&L.

## Formatting

P&L and Balance Sheet:

- No gridlines.
- No colors.
- No borders unless the user requests them.
- Bold only for title, section headers, totals, and net income or balance check.
- Currency format: `$#,##0.00;($#,##0.00);-`
- Minimal row spacing.
- No note section.

Transaction Detail:

- Gridlines may remain on.
- Freeze the header row.
- Bold the header row.
- Use date and currency number formats.
- Make description column wide enough to scan.
- Do not hide rows or columns.

## File Naming

Use:

```text
<Entity_Name>_<year>_PnL_BS_Detail.xlsx
```

Save in the active workspace output folder unless the user requests another location.
