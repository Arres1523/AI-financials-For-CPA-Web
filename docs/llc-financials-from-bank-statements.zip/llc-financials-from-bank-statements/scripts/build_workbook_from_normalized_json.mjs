import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const currencyFormat = '$#,##0.00;($#,##0.00);-';

function parseArgs(argv) {
  const args = { selfTest: false };
  for (let i = 2; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--self-test") {
      args.selfTest = true;
    } else if (arg === "--input") {
      args.input = argv[++i];
    } else if (arg === "--output") {
      args.output = argv[++i];
    }
  }
  return args;
}

function samplePayload(outputPath) {
  return {
    entityName: "Coxshire Investments LLC",
    year: 2025,
    cashAccounts: ["JPMorgan Chase ending 8009"],
    outputPath,
    transactions: [
      {
        date: "2025-07-01",
        sourceAccount: "JPMorgan Chase ending 8009",
        description: "Online Transfer to CHK ...1161 transaction#: 25327065170 07/01",
        amount: -3000,
        sourceCategory: "Transfers / ACH Payments",
        finalCategory: "Member distributions / transfers out",
        statement: "Balance Sheet",
        plLine: "",
        bsLine: "Member distributions / transfers out",
        type: "ACCT_XFER",
        sourceBalance: 7000,
      },
      {
        date: "2025-07-01",
        sourceAccount: "JPMorgan Chase ending 8009",
        description: "Online Transfer from CHK ...4307 transaction#: 25327069368",
        amount: 10000,
        sourceCategory: "Income / Cash Inflows",
        finalCategory: "Member capital contribution",
        statement: "Balance Sheet",
        plLine: "",
        bsLine: "Member capital contribution",
        type: "ACCT_XFER",
        sourceBalance: 10000,
      },
      {
        date: "2025-09-04",
        sourceAccount: "JPMorgan Chase ending 8009",
        description: "SERVICE CHARGES FOR THE MONTH OF AUGUST",
        amount: -95,
        sourceCategory: "Bank Fees",
        finalCategory: "Bank fees",
        statement: "P&L",
        plLine: "Bank fees",
        bsLine: "",
        type: "FEE_TRANSACTION",
        sourceBalance: 6905,
      },
      {
        date: "2025-09-29",
        sourceAccount: "JPMorgan Chase ending 8009",
        description: "FEE REVERSAL",
        amount: 95,
        sourceCategory: "Income / Cash Inflows",
        finalCategory: "Bank fee reversal",
        statement: "P&L",
        plLine: "Bank fees",
        bsLine: "",
        type: "REFUND_TRANSACTION",
        sourceBalance: 7000,
      },
      {
        date: "2025-10-01",
        sourceAccount: "JPMorgan Chase ending 8009",
        description: "Online Transfer to CHK ...1161 transaction#: 26425598371 10/01",
        amount: -5000,
        sourceCategory: "Transfers / ACH Payments",
        finalCategory: "Member distributions / transfers out",
        statement: "Balance Sheet",
        plLine: "",
        bsLine: "Member distributions / transfers out",
        type: "ACCT_XFER",
        sourceBalance: 2000,
      },
      {
        date: "2025-12-30",
        sourceAccount: "JPMorgan Chase ending 8009",
        description: "BOOK TRANSFER CREDIT B/O: VCP EQUITY MANAGEMENT LLC REF: MEMBER DISTRIBUTION 2025 NET CASH FLOW",
        amount: 45000,
        sourceCategory: "Income / Cash Inflows",
        finalCategory: "Investment distribution received",
        statement: "Balance Sheet",
        plLine: "",
        bsLine: "Investment distribution received",
        type: "WIRE_INCOMING",
        sourceBalance: 47000,
      },
    ],
  };
}

function toDate(value) {
  if (value instanceof Date) return value;
  const [year, month, day] = String(value).slice(0, 10).split("-").map(Number);
  return new Date(year, month - 1, day);
}

function uniqueNonBlank(values) {
  return [...new Set(values.filter((value) => String(value || "").trim()))];
}

function inferPlSections(transactions) {
  const totals = new Map();
  for (const tx of transactions) {
    if (tx.statement !== "P&L" || !tx.plLine) continue;
    totals.set(tx.plLine, (totals.get(tx.plLine) || 0) + Number(tx.amount || 0));
  }
  const income = [];
  const expenses = [];
  for (const [line, total] of totals.entries()) {
    if (total >= 0) income.push(line);
    else expenses.push(line);
  }
  if (income.length === 0) income.push("Operating income");
  if (expenses.length === 0) expenses.push("Bank fees");
  return { income, expenses };
}

function inferBsSections(transactions) {
  const lines = uniqueNonBlank(transactions.filter((tx) => tx.statement === "Balance Sheet").map((tx) => tx.bsLine));
  const assets = [];
  const liabilities = [];
  const equity = [];
  for (const line of lines) {
    const lower = line.toLowerCase();
    if (lower.includes("payable") || lower.includes("due to") || lower.includes("liability")) liabilities.push(line);
    else if (lower.includes("member") || lower.includes("equity") || lower.includes("capital") || lower.includes("distribution")) equity.push(line);
    else assets.push(line);
  }
  return { assets, liabilities, equity };
}

function cashFormula(lastRow, cashAccounts = []) {
  if (!cashAccounts.length) return `=SUM('Transaction Detail'!$D$2:$D$${lastRow})`;
  return "=" + cashAccounts.map((account) => {
    const safe = String(account).replaceAll('"', '""');
    return `SUMIFS('Transaction Detail'!$D$2:$D$${lastRow},'Transaction Detail'!$B$2:$B$${lastRow},"${safe}")`;
  }).join("+");
}

function statementStyle(sheet, usedRange, amountRange) {
  sheet.showGridLines = false;
  sheet.getRange(usedRange).format.font = { name: "Aptos", size: 11 };
  sheet.getRange("A1:A3").format = { font: { bold: true } };
  sheet.getRange(amountRange).format.numberFormat = currencyFormat;
  sheet.getRange("A1:A60").format.columnWidth = 46;
  sheet.getRange("B1:B60").format.columnWidth = 18;
}

async function buildWorkbook(payload) {
  const transactions = payload.transactions || [];
  if (!transactions.length) throw new Error("Payload must include transactions.");

  const outputPath = payload.outputPath;
  if (!outputPath) throw new Error("Payload must include outputPath, or pass --output.");

  const workbook = Workbook.create();
  const pl = workbook.worksheets.add(`P&L ${payload.year}`);
  const bs = workbook.worksheets.add("Balance Sheet");
  const detail = workbook.worksheets.add("Transaction Detail");

  const lastRow = transactions.length + 1;
  const detailValues = [
    ["Date", "Source Account", "Description", "Amount", "Source Category", "Final Category", "Statement", "P&L Line", "P&L Amount", "BS Line", "BS Counterpart Amount", "Type", "Source Balance", "Review Status"],
    ...transactions.map((tx) => [
      toDate(tx.date),
      tx.sourceAccount || "",
      tx.description || "",
      Number(tx.amount || 0),
      tx.sourceCategory || "",
      tx.finalCategory || "",
      tx.statement || "",
      tx.plLine || "",
      null,
      tx.bsLine || "",
      null,
      tx.type || "",
      tx.sourceBalance === undefined || tx.sourceBalance === null ? null : Number(tx.sourceBalance),
      tx.reviewStatus || "",
    ]),
  ];
  detail.getRange(`A1:N${lastRow}`).values = detailValues;
  detail.getRange(`I2:I${lastRow}`).formulas = Array.from({ length: transactions.length }, (_, index) => {
    const row = index + 2;
    return [`=IF($G${row}="P&L",$D${row},0)`];
  });
  detail.getRange(`K2:K${lastRow}`).formulas = Array.from({ length: transactions.length }, (_, index) => {
    const row = index + 2;
    return [`=IF($G${row}="Balance Sheet",$D${row},0)`];
  });
  detail.getRange("A1:N1").format = { font: { bold: true } };
  detail.getRange(`A2:A${lastRow}`).format.numberFormat = "yyyy-mm-dd";
  detail.getRange(`D2:D${lastRow}`).format.numberFormat = currencyFormat;
  detail.getRange(`I2:I${lastRow}`).format.numberFormat = currencyFormat;
  detail.getRange(`K2:K${lastRow}`).format.numberFormat = currencyFormat;
  detail.getRange(`M2:M${lastRow}`).format.numberFormat = currencyFormat;
  detail.freezePanes.freezeRows(1);
  detail.getRange("A:A").format.columnWidth = 12;
  detail.getRange("B:B").format.columnWidth = 28;
  detail.getRange("C:C").format.columnWidth = 72;
  detail.getRange("D:N").format.columnWidth = 20;

  const plSections = payload.plSections || inferPlSections(transactions);
  const plRows = [
    [payload.entityName, null],
    ["Profit and Loss", null],
    [`For the year ended December 31, ${payload.year}`, null],
    [null, null],
    ["Category", "Amount"],
    ["Income", null],
    ...plSections.income.map((line) => [line, null]),
    ["Total Income", null],
    [null, null],
    ["Expenses", null],
    ...plSections.expenses.map((line) => [line, null]),
    ["Total Expenses", null],
    [null, null],
    ["Net Income (Loss)", null],
  ];
  pl.getRange(`A1:B${plRows.length}`).values = plRows;
  const incomeStart = 7;
  const incomeEnd = incomeStart + plSections.income.length - 1;
  const totalIncomeRow = incomeEnd + 1;
  const expenseStart = totalIncomeRow + 3;
  const expenseEnd = expenseStart + plSections.expenses.length - 1;
  const totalExpenseRow = expenseEnd + 1;
  const netIncomeRow = totalExpenseRow + 2;
  for (let row = incomeStart; row <= incomeEnd; row += 1) {
    pl.getRange(`B${row}`).formulas = [[`=SUMIFS('Transaction Detail'!$I$2:$I$${lastRow},'Transaction Detail'!$H$2:$H$${lastRow},A${row})`]];
  }
  pl.getRange(`B${totalIncomeRow}`).formulas = [[`=SUM(B${incomeStart}:B${incomeEnd})`]];
  for (let row = expenseStart; row <= expenseEnd; row += 1) {
    pl.getRange(`B${row}`).formulas = [[`=-SUMIFS('Transaction Detail'!$I$2:$I$${lastRow},'Transaction Detail'!$H$2:$H$${lastRow},A${row})`]];
  }
  pl.getRange(`B${totalExpenseRow}`).formulas = [[`=SUM(B${expenseStart}:B${expenseEnd})`]];
  pl.getRange(`B${netIncomeRow}`).formulas = [[`=B${totalIncomeRow}-B${totalExpenseRow}`]];
  pl.getRange("A5:B5").format = { font: { bold: true } };
  for (const row of [6, totalIncomeRow, totalIncomeRow + 2, totalExpenseRow, netIncomeRow]) {
    pl.getRange(`A${row}:B${row}`).format = { font: { bold: true } };
  }
  statementStyle(pl, `A1:B${plRows.length}`, `B7:B${plRows.length}`);

  const bsSections = payload.bsSections || inferBsSections(transactions);
  const bsRows = [
    [payload.entityName, null],
    ["Balance Sheet", null],
    [`As of December 31, ${payload.year}`, null],
    [null, null],
    ["Category", "Amount"],
    ["Assets", null],
    [payload.cashLabel || "Cash", null],
    ...bsSections.assets.map((line) => [line, null]),
    ["Total Assets", null],
    [null, null],
    ["Liabilities", null],
    ...bsSections.liabilities.map((line) => [line, null]),
    ["Total Liabilities", null],
    [null, null],
    ["Equity", null],
    ["Beginning members' equity", payload.beginningEquity || 0],
    ...bsSections.equity.map((line) => [line, null]),
    ["Current year net income (loss)", null],
    ["Total Equity", null],
    [null, null],
    ["Total Liabilities and Equity", null],
    ["Balance Check", null],
  ];
  bs.getRange(`A1:B${bsRows.length}`).values = bsRows;
  let row = 7;
  bs.getRange(`B${row}`).formulas = [[cashFormula(lastRow, payload.cashAccounts || [])]];
  const assetStart = row + 1;
  const assetEnd = assetStart + bsSections.assets.length - 1;
  for (let r = assetStart; r <= assetEnd; r += 1) {
    bs.getRange(`B${r}`).formulas = [[`=SUMIFS('Transaction Detail'!$K$2:$K$${lastRow},'Transaction Detail'!$J$2:$J$${lastRow},A${r})`]];
  }
  const totalAssetsRow = assetEnd + 1;
  bs.getRange(`B${totalAssetsRow}`).formulas = [[`=SUM(B7:B${Math.max(7, assetEnd)})`]];
  const liabilitiesHeaderRow = totalAssetsRow + 2;
  const liabilitiesStart = liabilitiesHeaderRow + 1;
  const liabilitiesEnd = liabilitiesStart + bsSections.liabilities.length - 1;
  for (let r = liabilitiesStart; r <= liabilitiesEnd; r += 1) {
    bs.getRange(`B${r}`).formulas = [[`=SUMIFS('Transaction Detail'!$K$2:$K$${lastRow},'Transaction Detail'!$J$2:$J$${lastRow},A${r})`]];
  }
  const totalLiabilitiesRow = liabilitiesEnd + 1;
  bs.getRange(`B${totalLiabilitiesRow}`).formulas = [[`=SUM(B${liabilitiesStart}:B${Math.max(liabilitiesStart, liabilitiesEnd)})`]];
  const equityHeaderRow = totalLiabilitiesRow + 2;
  const beginningEquityRow = equityHeaderRow + 1;
  const equityStart = beginningEquityRow + 1;
  const equityEnd = equityStart + bsSections.equity.length - 1;
  for (let r = equityStart; r <= equityEnd; r += 1) {
    bs.getRange(`B${r}`).formulas = [[`=SUMIFS('Transaction Detail'!$K$2:$K$${lastRow},'Transaction Detail'!$J$2:$J$${lastRow},A${r})`]];
  }
  const currentYearNetIncomeRow = equityEnd + 1;
  const totalEquityRow = currentYearNetIncomeRow + 1;
  const totalLiabilitiesEquityRow = totalEquityRow + 2;
  const balanceCheckRow = totalLiabilitiesEquityRow + 1;
  bs.getRange(`B${currentYearNetIncomeRow}`).formulas = [[`='P&L ${payload.year}'!B${netIncomeRow}`]];
  bs.getRange(`B${totalEquityRow}`).formulas = [[`=SUM(B${beginningEquityRow}:B${currentYearNetIncomeRow})`]];
  bs.getRange(`B${totalLiabilitiesEquityRow}`).formulas = [[`=B${totalLiabilitiesRow}+B${totalEquityRow}`]];
  bs.getRange(`B${balanceCheckRow}`).formulas = [[`=B${totalAssetsRow}-B${totalLiabilitiesEquityRow}`]];
  bs.getRange("A5:B5").format = { font: { bold: true } };
  for (const boldRow of [6, totalAssetsRow, liabilitiesHeaderRow, totalLiabilitiesRow, equityHeaderRow, totalEquityRow, totalLiabilitiesEquityRow, balanceCheckRow]) {
    bs.getRange(`A${boldRow}:B${boldRow}`).format = { font: { bold: true } };
  }
  statementStyle(bs, `A1:B${bsRows.length}`, `B7:B${bsRows.length}`);

  const errors = await workbook.inspect({
    kind: "match",
    searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
    options: { useRegex: true, maxResults: 200 },
    summary: "formula error scan",
  });
  console.log(errors.ndjson);

  await fs.mkdir(path.dirname(outputPath), { recursive: true });
  const exported = await SpreadsheetFile.exportXlsx(workbook);
  await exported.save(outputPath);
  console.log(JSON.stringify({ outputPath, transactionCount: transactions.length }, null, 2));
}

const args = parseArgs(process.argv);
let payload;
if (args.selfTest) {
  const output = args.output || path.resolve("llc-financials-self-test.xlsx");
  payload = samplePayload(output);
} else {
  if (!args.input) throw new Error("Usage: node build_workbook_from_normalized_json.mjs --input normalized.json --output workbook.xlsx");
  payload = JSON.parse(await fs.readFile(args.input, "utf8"));
  if (args.output) payload.outputPath = args.output;
}

await buildWorkbook(payload);
